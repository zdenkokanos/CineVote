package GUI;

import com.sun.tools.javac.Main;

public class FakeMain {
    public static void main(String[] args){
        MainGUI.main(args);
    }
}
